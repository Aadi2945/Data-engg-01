use sales_weatherinfo_db;
select * from weather;
